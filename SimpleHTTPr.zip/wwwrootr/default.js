function dontshowerr() {return true;}
window.onerror=dontshowerr;